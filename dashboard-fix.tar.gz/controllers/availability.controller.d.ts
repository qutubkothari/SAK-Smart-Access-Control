import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const createAvailabilityBlock: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getAvailabilityBlocks: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateAvailabilityBlock: (req: AuthRequest, res: Response) => Promise<void>;
export declare const deleteAvailabilityBlock: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=availability.controller.d.ts.map