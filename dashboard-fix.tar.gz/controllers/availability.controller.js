"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteAvailabilityBlock = exports.updateAvailabilityBlock = exports.getAvailabilityBlocks = exports.createAvailabilityBlock = void 0;
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const createAvailabilityBlock = async (req, res) => {
    try {
        const { start_time, end_time, reason, type, all_day } = req.body;
        const userId = req.user.id;
        if (!start_time || !end_time) {
            res.status(422).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'start_time and end_time are required'
                }
            });
            return;
        }
        const [block] = await (0, database_1.default)('user_availability')
            .insert({
            user_id: userId,
            start_time,
            end_time,
            reason,
            type: type || 'busy',
            all_day: all_day || false
        })
            .returning('*');
        res.status(201).json({
            success: true,
            data: block
        });
    }
    catch (error) {
        logger_1.default.error('Error creating availability block:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create availability block'
            }
        });
    }
};
exports.createAvailabilityBlock = createAvailabilityBlock;
const getAvailabilityBlocks = async (req, res) => {
    try {
        const { user_id, start_date, end_date } = req.query;
        const requesterId = req.user.id;
        const isAdmin = req.user?.role === 'admin';
        // Users can see their own blocks, admins can see anyone's
        const targetUserId = isAdmin && user_id ? user_id : requesterId;
        let query = (0, database_1.default)('user_availability')
            .where('user_id', targetUserId)
            .orderBy('start_time', 'asc');
        if (start_date) {
            query = query.where('start_time', '>=', start_date);
        }
        if (end_date) {
            query = query.where('end_time', '<=', end_date);
        }
        const blocks = await query;
        res.json({
            success: true,
            data: blocks
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching availability blocks:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch availability blocks'
            }
        });
    }
};
exports.getAvailabilityBlocks = getAvailabilityBlocks;
const updateAvailabilityBlock = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        const userId = req.user.id;
        const block = await (0, database_1.default)('user_availability')
            .where({ id, user_id: userId })
            .first();
        if (!block) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'Availability block not found or unauthorized'
                }
            });
            return;
        }
        await (0, database_1.default)('user_availability')
            .where({ id })
            .update({
            ...updates,
            updated_at: new Date()
        });
        res.json({
            success: true,
            message: 'Availability block updated successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error updating availability block:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update availability block'
            }
        });
    }
};
exports.updateAvailabilityBlock = updateAvailabilityBlock;
const deleteAvailabilityBlock = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const result = await (0, database_1.default)('user_availability')
            .where({ id, user_id: userId })
            .delete();
        if (result === 0) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'Availability block not found or unauthorized'
                }
            });
            return;
        }
        res.json({
            success: true,
            message: 'Availability block deleted successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error deleting availability block:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to delete availability block'
            }
        });
    }
};
exports.deleteAvailabilityBlock = deleteAvailabilityBlock;
//# sourceMappingURL=availability.controller.js.map