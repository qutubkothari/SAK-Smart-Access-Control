import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const createMeeting: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getMeetingAvailability: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getMeetings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getMeetingById: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateMeeting: (req: AuthRequest, res: Response) => Promise<void>;
export declare const cancelMeeting: (req: AuthRequest, res: Response) => Promise<void>;
export declare const checkInHost: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=meeting.controller.d.ts.map