"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUser = exports.updateUser = exports.getUserById = exports.createUser = exports.getUsers = exports.searchHosts = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const searchHosts = async (req, res) => {
    try {
        const q = (req.query.q || '').trim();
        if (!q || q.length < 2) {
            res.json({ success: true, data: [] });
            return;
        }
        const hosts = await (0, database_1.default)('users')
            .leftJoin('departments', 'users.department_id', 'departments.id')
            .select('users.id', 'users.its_id', 'users.name', 'users.email', 'users.phone', 'users.department_id', 'departments.name as department_name', 'departments.floor_number', 'departments.building')
            .where('users.is_active', true)
            .where(function () {
            this.whereILike('users.name', `%${q}%`)
                .orWhereILike('users.its_id', `%${q}%`)
                .orWhereILike('users.email', `%${q}%`);
        })
            .limit(20);
        res.json({ success: true, data: hosts });
    }
    catch (error) {
        logger_1.default.error('Error searching hosts:', error);
        res.status(500).json({
            success: false,
            error: { code: 'INTERNAL_ERROR', message: 'Failed to search hosts' }
        });
    }
};
exports.searchHosts = searchHosts;
const getUsers = async (req, res) => {
    try {
        const { role, department_id, page = 1, limit = 50 } = req.query;
        const offset = (Number(page) - 1) * Number(limit);
        let query = (0, database_1.default)('users')
            .select('id', 'its_id', 'email', 'name', 'phone', 'department_id', 'role', 'is_active', 'created_at')
            .orderBy('created_at', 'desc');
        if (role) {
            query = query.where('role', role);
        }
        if (department_id) {
            query = query.where('department_id', department_id);
        }
        const [{ count }] = await query.clone().count('* as count');
        const users = await query.limit(Number(limit)).offset(offset);
        res.json({
            success: true,
            data: users,
            meta: {
                total: parseInt(count),
                page: Number(page),
                limit: Number(limit),
                total_pages: Math.ceil(parseInt(count) / Number(limit))
            }
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching users:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch users'
            }
        });
    }
};
exports.getUsers = getUsers;
const createUser = async (req, res) => {
    try {
        const { its_id, email, password, name, phone, department_id, role } = req.body;
        const existingUser = await (0, database_1.default)('users')
            .where({ its_id })
            .orWhere({ email })
            .first();
        if (existingUser) {
            res.status(422).json({
                success: false,
                error: {
                    code: 'USER_EXISTS',
                    message: 'User already exists'
                }
            });
            return;
        }
        const passwordHash = await bcryptjs_1.default.hash(password, parseInt(process.env.BCRYPT_ROUNDS || '10'));
        const [user] = await (0, database_1.default)('users')
            .insert({
            its_id,
            email,
            password_hash: passwordHash,
            name,
            phone,
            department_id,
            role: role || 'host'
        })
            .returning(['id', 'its_id', 'name', 'email', 'role']);
        res.status(201).json({
            success: true,
            data: { user }
        });
    }
    catch (error) {
        logger_1.default.error('Error creating user:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create user'
            }
        });
    }
};
exports.createUser = createUser;
const getUserById = async (req, res) => {
    try {
        const { id } = req.params;
        const user = await (0, database_1.default)('users')
            .select('id', 'its_id', 'email', 'name', 'phone', 'department_id', 'role', 'is_active', 'created_at')
            .where({ id })
            .first();
        if (!user) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'User not found'
                }
            });
            return;
        }
        res.json({
            success: true,
            data: user
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching user:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch user'
            }
        });
    }
};
exports.getUserById = getUserById;
const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        if (updates.password) {
            updates.password_hash = await bcryptjs_1.default.hash(updates.password, parseInt(process.env.BCRYPT_ROUNDS || '10'));
            delete updates.password;
        }
        await (0, database_1.default)('users')
            .where({ id })
            .update({
            ...updates,
            updated_at: new Date()
        });
        res.json({
            success: true,
            message: 'User updated successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error updating user:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update user'
            }
        });
    }
};
exports.updateUser = updateUser;
const deleteUser = async (req, res) => {
    try {
        const { id } = req.params;
        await (0, database_1.default)('users')
            .where({ id })
            .update({
            is_active: false,
            updated_at: new Date()
        });
        res.json({
            success: true,
            message: 'User deactivated successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error deactivating user:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to deactivate user'
            }
        });
    }
};
exports.deleteUser = deleteUser;
//# sourceMappingURL=user.controller.js.map