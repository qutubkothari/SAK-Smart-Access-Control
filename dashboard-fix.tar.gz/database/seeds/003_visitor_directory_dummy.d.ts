import { Knex } from 'knex';
export declare function seed(knex: Knex): Promise<void>;
//# sourceMappingURL=003_visitor_directory_dummy.d.ts.map