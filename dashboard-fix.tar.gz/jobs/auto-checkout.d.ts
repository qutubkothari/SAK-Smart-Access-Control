/**
 * Auto-checkout visitors 2 hours after meeting end time
 */
export declare const runAutoCheckout: () => Promise<void>;
/**
 * Schedule auto-checkout to run every 15 minutes
 */
export declare const startAutoCheckoutJob: () => void;
//# sourceMappingURL=auto-checkout.d.ts.map