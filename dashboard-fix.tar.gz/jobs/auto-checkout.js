"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.startAutoCheckoutJob = exports.runAutoCheckout = void 0;
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const node_cron_1 = __importDefault(require("node-cron"));
/**
 * Auto-checkout visitors 2 hours after meeting end time
 */
const runAutoCheckout = async () => {
    try {
        const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);
        const result = await (0, database_1.default)('visitors')
            .join('meetings', 'visitors.meeting_id', 'meetings.id')
            .whereNull('visitors.check_out_time')
            .whereNotNull('visitors.check_in_time')
            .whereRaw(`(meetings.meeting_time + (meetings.duration_minutes::text || ' minutes')::interval) < ?::timestamp`, [twoHoursAgo])
            .update({
            'visitors.check_out_time': new Date(),
            'visitors.updated_at': new Date()
        });
        if (result > 0) {
            logger_1.default.info(`Auto-checkout: ${result} visitors automatically checked out`);
        }
    }
    catch (error) {
        logger_1.default.error('Error in auto-checkout job:', error);
    }
};
exports.runAutoCheckout = runAutoCheckout;
/**
 * Schedule auto-checkout to run every 15 minutes
 */
const startAutoCheckoutJob = () => {
    node_cron_1.default.schedule('*/15 * * * *', exports.runAutoCheckout);
    logger_1.default.info('Auto-checkout job scheduled (runs every 15 minutes)');
};
exports.startAutoCheckoutJob = startAutoCheckoutJob;
//# sourceMappingURL=auto-checkout.js.map