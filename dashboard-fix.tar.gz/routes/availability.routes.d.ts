declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=availability.routes.d.ts.map