"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const availability_controller_1 = require("../controllers/availability.controller");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.post('/', (0, auth_1.authorize)('host', 'admin'), availability_controller_1.createAvailabilityBlock);
router.get('/', (0, auth_1.authorize)('host', 'admin'), availability_controller_1.getAvailabilityBlocks);
router.put('/:id', (0, auth_1.authorize)('host', 'admin'), availability_controller_1.updateAvailabilityBlock);
router.delete('/:id', (0, auth_1.authorize)('host', 'admin'), availability_controller_1.deleteAvailabilityBlock);
exports.default = router;
//# sourceMappingURL=availability.routes.js.map