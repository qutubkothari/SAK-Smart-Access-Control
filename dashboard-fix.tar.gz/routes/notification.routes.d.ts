declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=notification.routes.d.ts.map