interface EmailOptions {
    to: string;
    subject: string;
    html: string;
    attachments?: Array<{
        filename: string;
        content?: string;
        path?: string;
        cid?: string;
    }>;
}
declare class EmailService {
    private transporter;
    constructor();
    /**
     * Send email
     */
    sendEmail(options: EmailOptions): Promise<boolean>;
    /**
     * Send meeting invitation with QR code
     */
    sendMeetingInvitation(to: string, visitorName: string, hostName: string, meetingTime: string, location: string, purpose: string, qrCodeImage: string): Promise<boolean>;
    /**
     * Send visitor arrival notification to host
     */
    sendVisitorArrivalNotification(to: string, hostName: string, visitorName: string, company: string, location: string, arrivalTime: string): Promise<boolean>;
    /**
     * Send meeting reminder
     */
    sendMeetingReminder(to: string, hostName: string, meetingTime: string, location: string): Promise<boolean>;
}
declare const _default: EmailService;
export default _default;
//# sourceMappingURL=email.service.d.ts.map