"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const axios_1 = __importDefault(require("axios"));
const logger_1 = __importDefault(require("../utils/logger"));
class MaytapiService {
    constructor() {
        this.productId = process.env.MAYTAPI_PRODUCT_ID || '';
        this.phoneId = process.env.MAYTAPI_PHONE_ID || '';
        this.apiToken = process.env.MAYTAPI_API_KEY || '';
        this.baseUrl = `https://api.maytapi.com/api/${this.productId}/${this.phoneId}`;
        this.apiUrl = `${this.baseUrl}/sendMessage`;
    }
    /**
     * Send WhatsApp text message
     */
    async sendMessage(to, text) {
        try {
            if (!this.productId || !this.phoneId || !this.apiToken) {
                logger_1.default.warn('Maytapi not configured, skipping WhatsApp message');
                return null;
            }
            // Clean up currency symbols and ensure UTF-8
            let cleanText = text
                .replace(/â‚¹/g, '₹')
                .replace(/Rs\./g, '₹')
                .replace(/Rs\s+/g, '₹')
                .replace(/Ã¢â€šÂ¹/g, '₹')
                .replace(/Ã°Å¸â€œÂ¦/g, '📦')
                .replace(/Ã¢Å"â€¦/g, '✅')
                .replace(/Ã°Å¸â€™Â³/g, '💳')
                .trim();
            logger_1.default.info(`[WHATSAPP_SEND] Cleaned text preview: ${cleanText.substring(0, 100)}`);
            const response = await axios_1.default.post(this.apiUrl, {
                to_number: to,
                type: 'text',
                message: cleanText
            }, {
                headers: {
                    'Content-Type': 'application/json; charset=utf-8',
                    'x-maytapi-key': this.apiToken
                }
            });
            if (!response.data) {
                logger_1.default.error('Maytapi API error: No response data');
                return null;
            }
            logger_1.default.info(`WhatsApp text message sent to ${to}`);
            return response.data.data?.message_id || null;
        }
        catch (error) {
            logger_1.default.error('Error sending WhatsApp message:', error.response?.data || error.message);
            return null;
        }
    }
    /**
     * Send WhatsApp message with image
     */
    async sendMessageWithImage(to, caption, mediaUrl) {
        try {
            if (!this.productId || !this.phoneId || !this.apiToken) {
                logger_1.default.warn('Maytapi not configured, skipping WhatsApp message');
                return null;
            }
            const response = await axios_1.default.post(this.apiUrl, {
                to_number: to,
                type: 'media',
                message: mediaUrl,
                text: caption
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'x-maytapi-key': this.apiToken
                }
            });
            if (!response.data) {
                logger_1.default.error('Maytapi API error (Image): No response data');
                return null;
            }
            logger_1.default.info(`WhatsApp image message sent to ${to}`);
            return response.data.data?.message_id || null;
        }
        catch (error) {
            logger_1.default.error('Error sending WhatsApp image:', error.response?.data || error.message);
            return null;
        }
    }
    /**
     * Send document (PDF, etc.) via WhatsApp
     */
    async sendDocument(to, documentBuffer, filename, caption = '') {
        try {
            if (!this.productId || !this.phoneId || !this.apiToken) {
                logger_1.default.warn('Maytapi not configured, skipping WhatsApp document');
                return null;
            }
            logger_1.default.info(`[MAYTAPI_DOCUMENT] Sending document: ${filename} to: ${to}`);
            logger_1.default.info(`[MAYTAPI_DOCUMENT] Buffer size: ${documentBuffer.length} bytes`);
            const base64Data = documentBuffer.toString('base64');
            logger_1.default.info(`[MAYTAPI_DOCUMENT] Base64 data length: ${base64Data.length}`);
            const response = await axios_1.default.post(this.apiUrl, {
                to_number: to,
                type: 'document',
                text: caption,
                document: base64Data,
                filename: filename
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'x-maytapi-key': this.apiToken
                }
            });
            logger_1.default.info(`[MAYTAPI_DOCUMENT] Response status: ${response.status}`);
            logger_1.default.info(`[MAYTAPI_DOCUMENT] Response body: ${JSON.stringify(response.data, null, 2)}`);
            if (!response.data) {
                logger_1.default.error('Maytapi Document API Error: No response data');
                return null;
            }
            logger_1.default.info(`Document sent to ${to}: ${filename}`);
            return response.data.data?.message_id || response.data.message_id || 'document_sent';
        }
        catch (error) {
            logger_1.default.error('Error sending document via Maytapi:', error.response?.data || error.message);
            return null;
        }
    }
    /**
     * Send QR code via WhatsApp
     */
    async sendQRCode(to, visitorName, meetingDetails, _qrImageBase64) {
        try {
            const message = `🎫 *Meeting Invitation*\n\nHi ${visitorName},\n\n${meetingDetails}\n\n✅ Your QR code has been sent to your email.\n\n⚠️ Please show the QR code at reception when you arrive.\n\n_SAK Smart Access Control_`;
            return await this.sendMessage(to, message);
        }
        catch (error) {
            logger_1.default.error('Error sending QR code via WhatsApp:', error);
            return null;
        }
    }
    /**
     * Send visitor arrival notification to host
     */
    async notifyHostVisitorArrived(to, hostName, visitorName, location) {
        const message = `🔔 *Visitor Arrived*\n\nHi ${hostName},\n\n${visitorName} has arrived at ${location}.\n\nPlease proceed to meet your visitor.\n\n_SAK Smart Access Control_`;
        return await this.sendMessage(to, message);
    }
    /**
     * Send meeting reminder
     */
    async sendMeetingReminder(to, hostName, meetingTime, location) {
        const message = `⏰ *Meeting Reminder*\n\nHi ${hostName},\n\nYour meeting is scheduled at ${meetingTime} at ${location}.\n\nPlease check in at the meeting location.\n\n_SAK Smart Access Control_`;
        return await this.sendMessage(to, message);
    }
    /**
     * Check connection status
     */
    async checkStatus() {
        try {
            const response = await axios_1.default.get(`${this.baseUrl}/status`, {
                headers: {
                    'x-maytapi-key': this.apiToken
                }
            });
            return response.data;
        }
        catch (error) {
            logger_1.default.error('Error checking Maytapi status:', error);
            return null;
        }
    }
}
exports.default = new MaytapiService();
//# sourceMappingURL=maytapi.service.js.map