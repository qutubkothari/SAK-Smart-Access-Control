"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const qrcode_1 = __importDefault(require("qrcode"));
const crypto_1 = __importDefault(require("crypto"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const logger_1 = __importDefault(require("../utils/logger"));
const redis_1 = __importDefault(require("../config/redis"));
class QRCodeService {
    constructor() {
        this.secret = process.env.QR_CODE_SECRET || 'default_secret_change_this';
        this.jwtSecret = process.env.JWT_SECRET || 'change_this_jwt_secret';
    }
    /**
     * Generate secure JWT-based QR code for visitor
     * Industry standard: Signed JWT with one-time use token
     */
    generateShortQrId() {
        // Compact, URL-safe, human-friendly id (Base62) to keep QR payload small.
        // 9 bytes = 72 bits of entropy => ~13 Base62 chars.
        const alphabet = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        const bytes = crypto_1.default.randomBytes(9);
        let value = 0n;
        for (const b of bytes)
            value = (value << 8n) | BigInt(b);
        if (value === 0n)
            return '0';
        let out = '';
        const base = 62n;
        while (value > 0n) {
            const idx = Number(value % base);
            out = alphabet[idx] + out;
            value = value / base;
        }
        return out;
    }
    async generateQRCode(meetingId, visitorId, visitorEmail, expiryDate) {
        try {
            // Generate unique QR ID (jti - JWT ID)
            const qrId = this.generateShortQrId();
            // Create JWT payload with security claims
            const payload = {
                iss: 'SAK-Access-Control', // Issuer
                sub: visitorId, // Subject (visitor ID)
                aud: 'check-in-terminal', // Audience
                jti: qrId, // Unique token ID (prevents replay)
                meeting_id: meetingId,
                visitor_email: visitorEmail,
                exp: Math.floor(expiryDate.getTime() / 1000), // Expiry timestamp
                nbf: Math.floor(Date.now() / 1000), // Not before (current time)
                iat: Math.floor(Date.now() / 1000) // Issued at
            };
            // Sign JWT with secret
            const token = jsonwebtoken_1.default.sign(payload, this.jwtSecret, {
                algorithm: 'HS256'
            });
            // Store QR ID in Redis with expiry (for one-time use validation)
            const expirySeconds = Math.floor((expiryDate.getTime() - Date.now()) / 1000);
            await redis_1.default.setEx(`qr:${qrId}`, expirySeconds, JSON.stringify({
                visitor_id: visitorId,
                meeting_id: meetingId,
                used: false,
                created_at: new Date().toISOString()
            }));
            // Generate QR code image
            // IMPORTANT: encode the short QR id (jti) instead of the full JWT.
            // Dense JWT QRs are hard to scan on phone cameras (especially off screens).
            const qrImage = await qrcode_1.default.toDataURL(qrId, {
                errorCorrectionLevel: 'H',
                type: 'image/png',
                width: 400,
                margin: 2,
                color: {
                    dark: '#000000',
                    light: '#FFFFFF'
                }
            });
            logger_1.default.info(`Secure QR code generated for meeting ${meetingId}, QR ID: ${qrId}`);
            return {
                token,
                image: qrImage,
                qrId
            };
        }
        catch (error) {
            logger_1.default.error('Error generating QR code:', error);
            throw error;
        }
    }
    normalizeQrInput(input) {
        const raw = String(input || '').trim();
        if (!raw)
            return raw;
        // If the QR contains a URL, try to extract the last path segment.
        // Example: https://sac.saksolution.com/qr/<id>
        try {
            if (/^https?:\/\//i.test(raw)) {
                const url = new URL(raw);
                const segments = url.pathname.split('/').filter(Boolean);
                const last = segments[segments.length - 1];
                if (last)
                    return last;
            }
        }
        catch {
            // ignore
        }
        // Allow simple prefixes like "qr:<id>"
        const prefixMatch = raw.match(/^(?:qr:|sak:)(.+)$/i);
        if (prefixMatch?.[1])
            return prefixMatch[1].trim();
        return raw;
    }
    async markQrUsed(qrId, qrInfo) {
        const ttl = await redis_1.default.ttl(`qr:${qrId}`);
        if (ttl && ttl > 0) {
            await redis_1.default.setEx(`qr:${qrId}`, ttl, JSON.stringify(qrInfo));
            return;
        }
        await redis_1.default.set(`qr:${qrId}`, JSON.stringify(qrInfo));
    }
    /**
     * Verify a short QR id (jti) with one-time use enforcement.
     */
    async verifyQrId(qrIdInput) {
        const qrId = this.normalizeQrInput(qrIdInput);
        if (!qrId)
            return null;
        const qrData = await redis_1.default.get(`qr:${qrId}`);
        if (!qrData) {
            logger_1.default.warn(`QR code expired or invalid: ${qrId}`);
            return null;
        }
        const qrInfo = JSON.parse(qrData);
        if (qrInfo.used) {
            logger_1.default.warn(`QR code already used: ${qrId}`);
            return { error: 'QR_CODE_ALREADY_USED', message: 'This QR code has already been scanned' };
        }
        qrInfo.used = true;
        qrInfo.used_at = new Date().toISOString();
        await this.markQrUsed(qrId, qrInfo);
        logger_1.default.info(`QR id verified successfully: ${qrId}`);
        return {
            visitor_id: qrInfo.visitor_id,
            meeting_id: qrInfo.meeting_id,
            qr_id: qrId
        };
    }
    /**
     * Verify either a JWT token (legacy) or a short QR id / URL.
     */
    async verifyQrCodeInput(input) {
        const normalized = this.normalizeQrInput(input);
        // JWTs have 3 dot-separated parts.
        if (normalized.split('.').length === 3) {
            return this.verifyQRCode(normalized);
        }
        return this.verifyQrId(normalized);
    }
    /**
     * Verify JWT-based QR code with one-time use enforcement
     */
    async verifyQRCode(token) {
        try {
            const normalized = this.normalizeQrInput(token);
            // Verify and decode JWT
            const decoded = jsonwebtoken_1.default.verify(normalized, this.jwtSecret, {
                algorithms: ['HS256'],
                audience: 'check-in-terminal',
                issuer: 'SAK-Access-Control'
            });
            // Check if QR has already been used (replay attack prevention)
            const qrData = await redis_1.default.get(`qr:${decoded.jti}`);
            if (!qrData) {
                logger_1.default.warn(`QR code expired or invalid: ${decoded.jti}`);
                return null;
            }
            const qrInfo = JSON.parse(qrData);
            if (qrInfo.used) {
                logger_1.default.warn(`QR code already used: ${decoded.jti}`);
                return { error: 'QR_CODE_ALREADY_USED', message: 'This QR code has already been scanned' };
            }
            // Mark QR as used
            qrInfo.used = true;
            qrInfo.used_at = new Date().toISOString();
            await this.markQrUsed(decoded.jti, qrInfo);
            logger_1.default.info(`QR code verified successfully: ${decoded.jti}`);
            return {
                visitor_id: decoded.sub,
                meeting_id: decoded.meeting_id,
                visitor_email: decoded.visitor_email,
                qr_id: decoded.jti
            };
        }
        catch (error) {
            if (error instanceof jsonwebtoken_1.default.TokenExpiredError) {
                logger_1.default.warn('QR code token expired');
                return { error: 'QR_CODE_EXPIRED', message: 'QR code has expired' };
            }
            if (error instanceof jsonwebtoken_1.default.JsonWebTokenError) {
                logger_1.default.warn('Invalid QR code token');
                return { error: 'INVALID_QR_CODE', message: 'Invalid QR code' };
            }
            logger_1.default.error('Error verifying QR code:', error);
            return null;
        }
    }
    /**
     * Revoke QR code (for cancellations)
     */
    async revokeQRCode(qrId) {
        try {
            const result = await redis_1.default.del(`qr:${qrId}`);
            logger_1.default.info(`QR code revoked: ${qrId}`);
            return result > 0;
        }
        catch (error) {
            logger_1.default.error('Error revoking QR code:', error);
            return false;
        }
    }
    /**
     * Legacy: Encrypt data using AES-256 with random salt (DEPRECATED)
     * Kept for backward compatibility only
     * @deprecated
     */
    // @ts-expect-error - Deprecated method kept for backward compatibility
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _encrypt(text) {
        const iv = crypto_1.default.randomBytes(16);
        const salt = crypto_1.default.randomBytes(32); // Random salt per encryption
        const key = crypto_1.default.scryptSync(this.secret, salt, 32);
        const cipher = crypto_1.default.createCipheriv('aes-256-cbc', key, iv);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        return iv.toString('hex') + ':' + salt.toString('hex') + ':' + encrypted;
    }
    /**
     * Legacy: Decrypt data (DEPRECATED)
     * @deprecated
     */
    // @ts-expect-error - Deprecated method kept for backward compatibility
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _decrypt(text) {
        const [ivHex, saltHex, encryptedHex] = text.split(':');
        const iv = Buffer.from(ivHex, 'hex');
        const salt = Buffer.from(saltHex, 'hex');
        const key = crypto_1.default.scryptSync(this.secret, salt, 32);
        const decipher = crypto_1.default.createDecipheriv('aes-256-cbc', key, iv);
        let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }
}
exports.default = new QRCodeService();
//# sourceMappingURL=qrcode.service.js.map