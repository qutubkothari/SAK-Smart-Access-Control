"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logout = exports.refresh = exports.register = exports.login = void 0;
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const login = async (req, res) => {
    try {
        const { its_id, password } = req.body;
        if (!its_id || !password) {
            res.status(422).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'ITS ID and password are required'
                }
            });
            return;
        }
        const user = await (0, database_1.default)('users').where({ its_id }).first();
        if (!user || !user.is_active) {
            res.status(401).json({
                success: false,
                error: {
                    code: 'INVALID_CREDENTIALS',
                    message: 'Invalid ITS ID or password'
                }
            });
            return;
        }
        const isPasswordValid = await bcryptjs_1.default.compare(password, user.password_hash);
        if (!isPasswordValid) {
            res.status(401).json({
                success: false,
                error: {
                    code: 'INVALID_CREDENTIALS',
                    message: 'Invalid ITS ID or password'
                }
            });
            return;
        }
        const token = jsonwebtoken_1.default.sign({
            id: user.id,
            its_id: user.its_id,
            email: user.email,
            role: user.role
        }, process.env.JWT_SECRET, { expiresIn: '24h' });
        logger_1.default.info(`User logged in: ${user.its_id}`);
        res.json({
            success: true,
            data: {
                token,
                user: {
                    id: user.id,
                    its_id: user.its_id,
                    name: user.name,
                    email: user.email,
                    role: user.role,
                    department: user.department_id
                }
            }
        });
    }
    catch (error) {
        logger_1.default.error('Login error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Login failed'
            }
        });
    }
};
exports.login = login;
const register = async (req, res) => {
    try {
        const { its_id, email, password, name, phone, department_id } = req.body;
        // Check if user exists
        const existingUser = await (0, database_1.default)('users')
            .where({ its_id })
            .orWhere({ email })
            .first();
        if (existingUser) {
            res.status(422).json({
                success: false,
                error: {
                    code: 'USER_EXISTS',
                    message: 'User with this ITS ID or email already exists'
                }
            });
            return;
        }
        // Hash password
        const passwordHash = await bcryptjs_1.default.hash(password, parseInt(process.env.BCRYPT_ROUNDS || '10'));
        // Create user
        const [user] = await (0, database_1.default)('users')
            .insert({
            its_id,
            email,
            password_hash: passwordHash,
            name,
            phone,
            department_id,
            role: 'host'
        })
            .returning(['id', 'its_id', 'name', 'email', 'role']);
        logger_1.default.info(`New user registered: ${its_id}`);
        res.status(201).json({
            success: true,
            data: { user }
        });
    }
    catch (error) {
        logger_1.default.error('Registration error:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Registration failed'
            }
        });
    }
};
exports.register = register;
const refresh = async (_req, res) => {
    // Implement token refresh logic
    res.json({ success: true, message: 'Token refresh endpoint' });
};
exports.refresh = refresh;
const logout = async (_req, res) => {
    // Implement logout logic (blacklist token if needed)
    res.json({ success: true, message: 'Logged out successfully' });
};
exports.logout = logout;
//# sourceMappingURL=auth.controller.js.map