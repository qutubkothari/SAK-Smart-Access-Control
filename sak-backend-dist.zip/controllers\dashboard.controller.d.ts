import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const getDashboardStats: (_req: AuthRequest, res: Response) => Promise<void>;
export declare const getRecentActivity: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=dashboard.controller.d.ts.map