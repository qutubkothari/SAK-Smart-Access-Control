"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRecentActivity = exports.getDashboardStats = void 0;
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const getDashboardStats = async (_req, res) => {
    try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        // Today's stats
        const todayMeetings = await (0, database_1.default)('meetings')
            .whereBetween('meeting_time', [today, tomorrow])
            .count('* as count')
            .first();
        const activeVisitors = await (0, database_1.default)('visitors')
            .whereNotNull('check_in_time')
            .whereNull('check_out_time')
            .count('* as count')
            .first();
        const completedMeetings = await (0, database_1.default)('meetings')
            .whereBetween('meeting_time', [today, tomorrow])
            .where('status', 'completed')
            .count('* as count')
            .first();
        const noShows = await (0, database_1.default)('meetings')
            .whereBetween('meeting_time', [today, tomorrow])
            .where('status', 'no_show')
            .count('* as count')
            .first();
        // This week's stats
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay());
        const weekMeetings = await (0, database_1.default)('meetings')
            .where('meeting_time', '>=', weekStart)
            .count('* as count')
            .first();
        const weekVisitors = await (0, database_1.default)('visitors')
            .leftJoin('meetings', 'visitors.meeting_id', 'meetings.id')
            .where('meetings.meeting_time', '>=', weekStart)
            .countDistinct('visitors.email as count')
            .first();
        // Popular times
        const popularTimes = await (0, database_1.default)('meetings')
            .whereBetween('meeting_time', [weekStart, tomorrow])
            .select(database_1.default.raw('EXTRACT(HOUR FROM meeting_time) as hour'))
            .count('* as count')
            .groupBy('hour')
            .orderBy('count', 'desc')
            .limit(5);
        res.json({
            success: true,
            data: {
                today: {
                    total_meetings: parseInt(todayMeetings?.count || '0'),
                    active_visitors: parseInt(activeVisitors?.count || '0'),
                    completed_meetings: parseInt(completedMeetings?.count || '0'),
                    no_shows: parseInt(noShows?.count || '0')
                },
                this_week: {
                    total_meetings: parseInt(weekMeetings?.count || '0'),
                    unique_visitors: parseInt(weekVisitors?.count || '0')
                },
                popular_times: popularTimes
            }
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching dashboard stats:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch dashboard stats'
            }
        });
    }
};
exports.getDashboardStats = getDashboardStats;
const getRecentActivity = async (req, res) => {
    try {
        const { limit = 10 } = req.query;
        const recentActivity = await (0, database_1.default)('visitors')
            .leftJoin('meetings', 'visitors.meeting_id', 'meetings.id')
            .leftJoin('users', 'meetings.host_id', 'users.id')
            .select('visitors.name as visitor_name', 'visitors.company', 'visitors.check_in_time', 'visitors.check_out_time', 'meetings.location', 'users.name as host_name')
            .whereNotNull('visitors.check_in_time')
            .orderBy('visitors.check_in_time', 'desc')
            .limit(Number(limit));
        res.json({
            success: true,
            data: recentActivity
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching recent activity:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch recent activity'
            }
        });
    }
};
exports.getRecentActivity = getRecentActivity;
//# sourceMappingURL=dashboard.controller.js.map