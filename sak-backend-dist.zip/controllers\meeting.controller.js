"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkInHost = exports.cancelMeeting = exports.updateMeeting = exports.getMeetingById = exports.getMeetings = exports.createMeeting = void 0;
const qrcode_service_1 = __importDefault(require("../services/qrcode.service"));
const notification_service_1 = __importDefault(require("../services/notification.service"));
const database_1 = __importDefault(require("../config/database"));
const logger_1 = __importDefault(require("../utils/logger"));
const uuid_1 = require("uuid");
const qrcode_1 = __importDefault(require("qrcode"));
const createMeeting = async (req, res) => {
    try {
        const { host_id, meeting_time, duration_minutes, location, purpose, visitors } = req.body;
        const requesterId = req.user.id;
        // Validate input
        if (!host_id || !meeting_time || !location || !visitors || visitors.length === 0) {
            res.status(422).json({
                success: false,
                error: {
                    code: 'VALIDATION_ERROR',
                    message: 'Missing required fields'
                }
            });
            return;
        }
        // Create meeting
        const [meeting] = await (0, database_1.default)('meetings')
            .insert({
            host_id,
            meeting_time,
            duration_minutes: duration_minutes || 60,
            location,
            purpose,
            status: 'scheduled'
        })
            .returning('*');
        // Create visitors and generate QR codes
        const qrCodes = [];
        for (const visitor of visitors) {
            const visitorId = (0, uuid_1.v4)();
            // Generate secure JWT-based QR code
            const qrExpiresAt = new Date(meeting_time);
            qrExpiresAt.setHours(qrExpiresAt.getHours() + parseInt(process.env.QR_CODE_EXPIRY_HOURS || '24'));
            const qrCode = await qrcode_service_1.default.generateQRCode(meeting.id, visitorId, visitor.email, qrExpiresAt);
            // Insert visitor with the generated QR token (qr_code is UNIQUE+NOT NULL)
            const [visitorRecord] = await (0, database_1.default)('visitors')
                .insert({
                id: visitorId,
                meeting_id: meeting.id,
                its_id: visitor.its_id || null,
                name: visitor.name,
                email: visitor.email,
                phone: visitor.phone,
                company: visitor.company,
                visitor_type: visitor.visitor_type || 'guest',
                qr_code: qrCode.token,
                qr_code_expires_at: qrExpiresAt
            })
                .returning('*');
            // Send notifications with QR code
            await notification_service_1.default.sendMeetingInvite(visitorRecord, meeting, qrCode.image);
            qrCodes.push({
                visitor_id: visitorRecord.id,
                visitor_name: visitor.name,
                qr_code: qrCode.image,
                qr_token: qrCode.token,
                qr_id: qrCode.qrId,
                email_sent: true,
                whatsapp_sent: true
            });
        }
        logger_1.default.info(`Meeting created: ${meeting.id} by requester ${requesterId} for host ${host_id}`);
        res.status(201).json({
            success: true,
            data: {
                meeting_id: meeting.id,
                qr_codes: qrCodes
            }
        });
    }
    catch (error) {
        logger_1.default.error('Error creating meeting:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to create meeting'
            }
        });
    }
};
exports.createMeeting = createMeeting;
const getMeetings = async (req, res) => {
    try {
        const { status, date_from, date_to, page = 1, limit = 20 } = req.query;
        const userId = req.user.id;
        const offset = (Number(page) - 1) * Number(limit);
        const countQuery = (0, database_1.default)('meetings').where('host_id', userId);
        let query = (0, database_1.default)('meetings')
            .where('host_id', userId)
            .orderBy('meeting_time', 'desc');
        if (status) {
            countQuery.where('status', status);
            query = query.where('status', status);
        }
        if (date_from) {
            countQuery.where('meeting_time', '>=', date_from);
            query = query.where('meeting_time', '>=', date_from);
        }
        if (date_to) {
            countQuery.where('meeting_time', '<=', date_to);
            query = query.where('meeting_time', '<=', date_to);
        }
        const [{ count }] = await countQuery.count('* as count');
        const meetings = await query.limit(Number(limit)).offset(offset);
        res.json({
            success: true,
            data: meetings,
            meta: {
                total: parseInt(count),
                page: Number(page),
                limit: Number(limit),
                total_pages: Math.ceil(parseInt(count) / Number(limit))
            }
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching meetings:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch meetings'
            }
        });
    }
};
exports.getMeetings = getMeetings;
const getMeetingById = async (req, res) => {
    try {
        const { id } = req.params;
        const meeting = await (0, database_1.default)('meetings')
            .where({ id })
            .first();
        if (!meeting) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'Meeting not found'
                }
            });
            return;
        }
        const visitors = await (0, database_1.default)('visitors')
            .where('meeting_id', id);
        let qrCodeUrl;
        const token = visitors?.[0]?.qr_code;
        if (token) {
            try {
                qrCodeUrl = await qrcode_1.default.toDataURL(token, {
                    errorCorrectionLevel: 'H',
                    type: 'image/png',
                    width: 400,
                    margin: 2,
                    color: {
                        dark: '#000000',
                        light: '#FFFFFF'
                    }
                });
            }
            catch (e) {
                logger_1.default.warn('Failed to render QR code image for meeting', { meeting_id: id, error: e });
            }
        }
        res.json({
            success: true,
            data: {
                ...meeting,
                qr_code_url: qrCodeUrl,
                visitors
            }
        });
    }
    catch (error) {
        logger_1.default.error('Error fetching meeting:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to fetch meeting'
            }
        });
    }
};
exports.getMeetingById = getMeetingById;
const updateMeeting = async (req, res) => {
    try {
        const { id } = req.params;
        const updates = req.body;
        const userId = req.user.id;
        const meeting = await (0, database_1.default)('meetings').where({ id, host_id: userId }).first();
        if (!meeting) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'Meeting not found or unauthorized'
                }
            });
            return;
        }
        await (0, database_1.default)('meetings').where({ id }).update({
            ...updates,
            updated_at: new Date()
        });
        res.json({
            success: true,
            message: 'Meeting updated successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error updating meeting:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to update meeting'
            }
        });
    }
};
exports.updateMeeting = updateMeeting;
const cancelMeeting = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const meeting = await (0, database_1.default)('meetings').where({ id, host_id: userId }).first();
        if (!meeting) {
            res.status(404).json({
                success: false,
                error: {
                    code: 'NOT_FOUND',
                    message: 'Meeting not found or unauthorized'
                }
            });
            return;
        }
        await (0, database_1.default)('meetings').where({ id }).update({
            status: 'cancelled',
            updated_at: new Date()
        });
        // Notify visitors
        const visitors = await (0, database_1.default)('visitors').where('meeting_id', id);
        for (const visitor of visitors) {
            await notification_service_1.default.sendCancellationNotice(visitor, meeting);
        }
        res.json({
            success: true,
            message: 'Meeting cancelled successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error cancelling meeting:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to cancel meeting'
            }
        });
    }
};
exports.cancelMeeting = cancelMeeting;
const checkInHost = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        await (0, database_1.default)('meetings').where({ id, host_id: userId }).update({
            host_checked_in: true,
            host_check_in_time: new Date()
        });
        res.json({
            success: true,
            message: 'Host checked in successfully'
        });
    }
    catch (error) {
        logger_1.default.error('Error checking in host:', error);
        res.status(500).json({
            success: false,
            error: {
                code: 'INTERNAL_ERROR',
                message: 'Failed to check in'
            }
        });
    }
};
exports.checkInHost = checkInHost;
//# sourceMappingURL=meeting.controller.js.map