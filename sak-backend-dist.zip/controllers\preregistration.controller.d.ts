import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/auth';
/**
 * Visitor Pre-Registration Controller
 * Allows visitors to register themselves before their visit
 */
export declare const preRegisterVisitor: (req: Request, res: Response) => Promise<void>;
export declare const getPreRegisteredVisitors: (req: AuthRequest, res: Response) => Promise<void>;
export declare const uploadVisitorPhoto: (req: AuthRequest, res: Response) => Promise<void>;
export declare const approvePreRegistration: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=preregistration.controller.d.ts.map