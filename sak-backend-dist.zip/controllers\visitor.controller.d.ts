import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const checkInVisitor: (req: AuthRequest, res: Response) => Promise<void>;
export declare const checkOutVisitor: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getVisitors: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getVisitorById: (req: AuthRequest, res: Response) => Promise<void>;
export declare const lookupVisitor: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=visitor.controller.d.ts.map