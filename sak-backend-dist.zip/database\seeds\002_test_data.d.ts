import { Knex } from 'knex';
export declare function seed(knex: Knex): Promise<void>;
//# sourceMappingURL=002_test_data.d.ts.map