import { Request, Response } from 'express';
export declare const notFound: (req: Request, res: Response) => void;
//# sourceMappingURL=notFound.d.ts.map