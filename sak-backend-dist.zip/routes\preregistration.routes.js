"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const auth_1 = require("../middleware/auth");
const preregistration_controller_1 = require("../controllers/preregistration.controller");
const router = (0, express_1.Router)();
// Multer configuration for photo uploads
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB limit
    },
    fileFilter: (_req, file, cb) => {
        // Accept only images
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        }
        else {
            cb(new Error('Only image files are allowed'));
        }
    }
});
// Public route - no authentication required
router.post('/register', preregistration_controller_1.preRegisterVisitor);
// Protected routes - require authentication
router.use(auth_1.authenticate);
router.get('/visitors', (0, auth_1.authorize)('host', 'admin', 'security'), preregistration_controller_1.getPreRegisteredVisitors);
router.post('/visitors/:visitor_id/photo', upload.single('photo'), preregistration_controller_1.uploadVisitorPhoto);
router.post('/visitors/:visitor_id/approve', (0, auth_1.authorize)('host', 'admin'), preregistration_controller_1.approvePreRegistration);
exports.default = router;
//# sourceMappingURL=preregistration.routes.js.map