"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const user_controller_1 = require("../controllers/user.controller");
const router = (0, express_1.Router)();
router.use(auth_1.authenticate);
router.get('/search-hosts', user_controller_1.searchHosts);
router.use((0, auth_1.authorize)('admin'));
router.get('/', user_controller_1.getUsers);
router.post('/', user_controller_1.createUser);
router.get('/:id', user_controller_1.getUserById);
router.put('/:id', user_controller_1.updateUser);
router.delete('/:id', user_controller_1.deleteUser);
exports.default = router;
//# sourceMappingURL=user.routes.js.map