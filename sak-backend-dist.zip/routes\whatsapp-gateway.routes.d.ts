declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=whatsapp-gateway.routes.d.ts.map