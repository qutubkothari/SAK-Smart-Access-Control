declare class MaytapiService {
    private productId;
    private phoneId;
    private apiToken;
    private apiUrl;
    private baseUrl;
    constructor();
    /**
     * Send WhatsApp text message
     */
    sendMessage(to: string, text: string): Promise<string | null>;
    /**
     * Send WhatsApp message with image
     */
    sendMessageWithImage(to: string, caption: string, mediaUrl: string): Promise<string | null>;
    /**
     * Send document (PDF, etc.) via WhatsApp
     */
    sendDocument(to: string, documentBuffer: Buffer, filename: string, caption?: string): Promise<string | null>;
    /**
     * Send QR code via WhatsApp
     */
    sendQRCode(to: string, visitorName: string, meetingDetails: string, _qrImageBase64: string): Promise<string | null>;
    /**
     * Send visitor arrival notification to host
     */
    notifyHostVisitorArrived(to: string, hostName: string, visitorName: string, location: string): Promise<string | null>;
    /**
     * Send meeting reminder
     */
    sendMeetingReminder(to: string, hostName: string, meetingTime: string, location: string): Promise<string | null>;
    /**
     * Check connection status
     */
    checkStatus(): Promise<any>;
}
declare const _default: MaytapiService;
export default _default;
//# sourceMappingURL=maytapi.service.d.ts.map