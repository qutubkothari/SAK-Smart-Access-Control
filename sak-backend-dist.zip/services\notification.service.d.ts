declare class NotificationService {
    /**
     * Send meeting invite to visitor with QR code
     */
    sendMeetingInvite(visitor: any, meeting: any, qrCodeImage: string): Promise<void>;
    /**
     * Send visitor arrival notification to host
     */
    sendVisitorArrivalNotification(host: any, visitor: any, meeting: any): Promise<void>;
    /**
     * Send meeting reminder to host
     */
    sendMeetingReminder(host: any, meeting: any): Promise<void>;
    /**
     * Send meeting cancellation notice
     */
    sendCancellationNotice(visitor: any, meeting: any): Promise<void>;
}
declare const _default: NotificationService;
export default _default;
//# sourceMappingURL=notification.service.d.ts.map