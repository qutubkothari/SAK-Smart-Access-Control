interface SessionConfig {
    sessionId: string;
    name: string;
    phoneNumber?: string;
    webhook?: string;
    apiKey: string;
    isActive: boolean;
}
/**
 * Multi-tenant WhatsApp Gateway Service
 * Similar to Maytapi but self-hosted and free
 */
declare class WhatsAppGatewayService {
    private sessions;
    private sessionConfigs;
    private qrCodes;
    private connectionStatus;
    private messageQueue;
    private authBaseFolder;
    constructor();
    /**
     * Initialize gateway service
     */
    private initialize;
    /**
     * Create a new WhatsApp session (like creating a new Maytapi phone)
     */
    createSession(config: SessionConfig): Promise<{
        success: boolean;
        sessionId: string;
        qrCode?: string;
        message: string;
    }>;
    /**
     * Handle incoming messages (for webhook forwarding)
     */
    private handleIncomingMessage;
    /**
     * Call webhook URL with data
     */
    private callWebhook;
    /**
     * Validate API key for session
     */
    validateApiKey(sessionId: string, apiKey: string): boolean;
    /**
     * Get session status
     */
    getSessionStatus(sessionId: string): {
        exists: boolean;
        connected: boolean;
        phoneNumber?: string;
        qrCode?: string;
    };
    /**
     * Send text message
     */
    sendMessage(sessionId: string, to: string, text: string): Promise<{
        success: boolean;
        messageId?: string;
        error?: string;
    }>;
    /**
     * Send image with caption
     */
    sendImage(sessionId: string, to: string, imageBuffer: Buffer, caption?: string): Promise<{
        success: boolean;
        messageId?: string;
        error?: string;
    }>;
    /**
     * Send document
     */
    sendDocument(sessionId: string, to: string, documentBuffer: Buffer, filename: string, caption?: string): Promise<{
        success: boolean;
        messageId?: string;
        error?: string;
    }>;
    /**
     * Queue message for retry
     */
    private queueMessage;
    /**
     * Process queued messages for a session
     */
    private processMessageQueue;
    /**
     * Format phone number
     */
    private formatPhoneNumber;
    /**
     * Delete session
     */
    deleteSession(sessionId: string): Promise<boolean>;
    /**
     * List all sessions
     */
    listSessions(): SessionConfig[];
}
declare const _default: WhatsAppGatewayService;
export default _default;
//# sourceMappingURL=whatsapp-gateway.service.d.ts.map