"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const baileys_1 = __importStar(require("@whiskeysockets/baileys"));
const logger_1 = __importDefault(require("../utils/logger"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const pino_1 = __importDefault(require("pino"));
class WhatsAppService {
    constructor() {
        this.sock = null;
        this.authFolder = path.join(process.cwd(), 'whatsapp_auth');
        this.isConnected = false;
        this.qrCode = null;
        this.initialize();
    }
    /**
     * Initialize WhatsApp connection
     */
    async initialize() {
        try {
            // Ensure auth folder exists
            if (!fs.existsSync(this.authFolder)) {
                fs.mkdirSync(this.authFolder, { recursive: true });
            }
            const { state, saveCreds } = await (0, baileys_1.useMultiFileAuthState)(this.authFolder);
            this.sock = (0, baileys_1.default)({
                auth: state,
                printQRInTerminal: true,
                logger: (0, pino_1.default)({ level: 'silent' })
            });
            // Connection events
            this.sock.ev.on('connection.update', async (update) => {
                const { connection, lastDisconnect, qr } = update;
                if (qr) {
                    this.qrCode = qr;
                    logger_1.default.info('📱 WhatsApp QR Code generated - scan with your phone');
                    // You can emit this QR to frontend for scanning
                }
                if (connection === 'close') {
                    const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== baileys_1.DisconnectReason.loggedOut;
                    logger_1.default.info('❌ WhatsApp connection closed, reconnecting:', shouldReconnect);
                    if (shouldReconnect) {
                        await this.initialize();
                    }
                    this.isConnected = false;
                }
                else if (connection === 'open') {
                    logger_1.default.info('✅ WhatsApp connection established successfully');
                    this.isConnected = true;
                    this.qrCode = null;
                }
            });
            // Save credentials when updated
            this.sock.ev.on('creds.update', saveCreds);
        }
        catch (error) {
            logger_1.default.error('Error initializing WhatsApp:', error);
        }
    }
    /**
     * Get current QR code for scanning
     */
    getQRCode() {
        return this.qrCode;
    }
    /**
     * Check if WhatsApp is connected
     */
    isWhatsAppConnected() {
        return this.isConnected;
    }
    /**
     * Format phone number for WhatsApp (add country code and @s.whatsapp.net)
     */
    formatPhoneNumber(phone) {
        // Remove all non-digit characters
        let cleaned = phone.replace(/\D/g, '');
        // Add country code if missing (assuming India +91)
        if (!cleaned.startsWith('91') && cleaned.length === 10) {
            cleaned = '91' + cleaned;
        }
        return cleaned + '@s.whatsapp.net';
    }
    /**
     * Send WhatsApp text message
     */
    async sendMessage(to, text) {
        try {
            if (!this.sock || !this.isConnected) {
                logger_1.default.warn('WhatsApp not connected, skipping message');
                return null;
            }
            const jid = this.formatPhoneNumber(to);
            // Clean up currency symbols and ensure UTF-8
            const cleanText = text
                .replace(/â‚¹/g, '₹')
                .replace(/Rs\./g, '₹')
                .replace(/Rs\s+/g, '₹')
                .trim();
            await this.sock.sendMessage(jid, { text: cleanText });
            logger_1.default.info(`WhatsApp text message sent to ${to}`);
            return 'message_sent';
        }
        catch (error) {
            logger_1.default.error('Error sending WhatsApp message:', error);
            return null;
        }
    }
    /**
     * Send WhatsApp message with image
     */
    async sendMessageWithImage(to, caption, imageBuffer) {
        try {
            if (!this.sock || !this.isConnected) {
                logger_1.default.warn('WhatsApp not connected, skipping message');
                return null;
            }
            const jid = this.formatPhoneNumber(to);
            await this.sock.sendMessage(jid, {
                image: imageBuffer,
                caption: caption
            });
            logger_1.default.info(`WhatsApp image message sent to ${to}`);
            return 'message_sent';
        }
        catch (error) {
            logger_1.default.error('Error sending WhatsApp image:', error);
            return null;
        }
    }
    /**
     * Send document (PDF, etc.) via WhatsApp
     */
    async sendDocument(to, documentBuffer, filename, caption = '') {
        try {
            if (!this.sock || !this.isConnected) {
                logger_1.default.warn('WhatsApp not connected, skipping document');
                return null;
            }
            const jid = this.formatPhoneNumber(to);
            await this.sock.sendMessage(jid, {
                document: documentBuffer,
                fileName: filename,
                caption: caption,
                mimetype: 'application/pdf'
            });
            logger_1.default.info(`WhatsApp document sent to ${to}: ${filename}`);
            return 'document_sent';
        }
        catch (error) {
            logger_1.default.error('Error sending WhatsApp document:', error);
            return null;
        }
    }
    /**
     * Send QR code via WhatsApp (with image)
     */
    async sendQRCode(to, visitorName, meetingDetails, qrImageBuffer) {
        try {
            const message = `🎫 *Meeting Invitation*\n\nHi ${visitorName},\n\n${meetingDetails}\n\n✅ Please show this QR code at reception when you arrive.\n\n_SAK Smart Access Control_`;
            return await this.sendMessageWithImage(to, message, qrImageBuffer);
        }
        catch (error) {
            logger_1.default.error('Error sending QR code via WhatsApp:', error);
            return null;
        }
    }
    /**
     * Send visitor arrival notification to host
     */
    async notifyHostVisitorArrived(to, hostName, visitorName, location) {
        const message = `🔔 *Visitor Arrived*\n\nHi ${hostName},\n\n${visitorName} has arrived at ${location}.\n\nPlease proceed to meet your visitor.\n\n_SAK Smart Access Control_`;
        return await this.sendMessage(to, message);
    }
    /**
     * Send meeting reminder
     */
    async sendMeetingReminder(to, hostName, meetingTime, location) {
        const message = `⏰ *Meeting Reminder*\n\nHi ${hostName},\n\nYour meeting is scheduled at ${meetingTime} at ${location}.\n\nPlease check in at the meeting location.\n\n_SAK Smart Access Control_`;
        return await this.sendMessage(to, message);
    }
    /**
     * Disconnect WhatsApp
     */
    async disconnect() {
        if (this.sock) {
            await this.sock.logout();
            this.sock = null;
            this.isConnected = false;
            logger_1.default.info('WhatsApp disconnected');
        }
    }
}
exports.default = new WhatsAppService();
//# sourceMappingURL=whatsapp.service.js.map