import knex from 'knex';
declare const db: knex.Knex<any, unknown[]>;
export default db;
//# sourceMappingURL=database.d.ts.map