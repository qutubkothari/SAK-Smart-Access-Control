"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const meeting_controller_1 = require("../controllers/meeting.controller");
const router = (0, express_1.Router)();
// All routes require authentication
router.use(auth_1.authenticate);
router.post('/', meeting_controller_1.createMeeting);
router.get('/', meeting_controller_1.getMeetings);
router.get('/:id', meeting_controller_1.getMeetingById);
router.put('/:id', meeting_controller_1.updateMeeting);
router.delete('/:id', meeting_controller_1.cancelMeeting);
router.post('/:id/check-in', meeting_controller_1.checkInHost);
exports.default = router;
//# sourceMappingURL=meeting.routes.js.map