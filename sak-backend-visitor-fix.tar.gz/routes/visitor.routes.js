"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const auth_1 = require("../middleware/auth");
const visitor_controller_1 = require("../controllers/visitor.controller");
const router = (0, express_1.Router)();
// Multer configuration for photo uploads
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB limit
    },
    fileFilter: (_req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        }
        else {
            cb(new Error('Only image files are allowed'));
        }
    }
});
router.use(auth_1.authenticate);
router.post('/check-in', (0, auth_1.authorize)('receptionist', 'security', 'admin'), upload.single('photo'), visitor_controller_1.checkInVisitor);
router.post('/:id/check-out', (0, auth_1.authorize)('receptionist', 'security', 'admin'), visitor_controller_1.checkOutVisitor);
router.get('/lookup', visitor_controller_1.lookupVisitor);
router.get('/', (0, auth_1.authorize)('admin', 'security'), visitor_controller_1.getVisitors);
router.get('/:id', visitor_controller_1.getVisitorById);
exports.default = router;
//# sourceMappingURL=visitor.routes.js.map