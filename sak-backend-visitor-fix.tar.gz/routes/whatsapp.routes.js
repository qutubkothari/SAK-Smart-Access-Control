"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_1 = require("../middleware/auth");
const whatsapp_service_1 = __importDefault(require("../services/whatsapp.service"));
const router = (0, express_1.Router)();
// Protect all routes with authentication
router.use(auth_1.authenticate);
/**
 * Get WhatsApp connection status
 */
router.get('/status', (0, auth_1.authorize)('admin'), async (_req, res) => {
    try {
        const isConnected = whatsapp_service_1.default.isWhatsAppConnected();
        return res.json({
            success: true,
            data: {
                connected: isConnected,
                message: isConnected ? 'WhatsApp is connected' : 'WhatsApp is not connected'
            }
        });
    }
    catch (error) {
        return res.status(500).json({
            success: false,
            error: {
                code: 'WHATSAPP_STATUS_ERROR',
                message: error.message
            }
        });
    }
});
/**
 * Get WhatsApp QR code for pairing
 */
router.get('/qr-code', (0, auth_1.authorize)('admin'), async (_req, res) => {
    try {
        const qrCode = whatsapp_service_1.default.getQRCode();
        if (!qrCode) {
            return res.json({
                success: true,
                data: {
                    qrCode: null,
                    message: 'WhatsApp is already connected or QR code not generated yet'
                }
            });
        }
        return res.json({
            success: true,
            data: {
                qrCode,
                message: 'Scan this QR code with WhatsApp on your phone'
            }
        });
    }
    catch (error) {
        return res.status(500).json({
            success: false,
            error: {
                code: 'WHATSAPP_QR_ERROR',
                message: error.message
            }
        });
    }
});
/**
 * Reinitialize WhatsApp connection
 */
router.post('/reconnect', (0, auth_1.authorize)('admin'), async (_req, res) => {
    try {
        await whatsapp_service_1.default.initialize();
        return res.json({
            success: true,
            message: 'WhatsApp reconnection initiated'
        });
    }
    catch (error) {
        return res.status(500).json({
            success: false,
            error: {
                code: 'WHATSAPP_RECONNECT_ERROR',
                message: error.message
            }
        });
    }
});
/**
 * Disconnect WhatsApp
 */
router.post('/disconnect', (0, auth_1.authorize)('admin'), async (_req, res) => {
    try {
        await whatsapp_service_1.default.disconnect();
        return res.json({
            success: true,
            message: 'WhatsApp disconnected successfully'
        });
    }
    catch (error) {
        return res.status(500).json({
            success: false,
            error: {
                code: 'WHATSAPP_DISCONNECT_ERROR',
                message: error.message
            }
        });
    }
});
exports.default = router;
//# sourceMappingURL=whatsapp.routes.js.map