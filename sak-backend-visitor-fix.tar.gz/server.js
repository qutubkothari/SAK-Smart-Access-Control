"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.io = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const dotenv_1 = __importDefault(require("dotenv"));
const http_1 = __importDefault(require("http"));
const socket_io_1 = require("socket.io");
const errorHandler_1 = require("./middleware/errorHandler");
const notFound_1 = require("./middleware/notFound");
const rateLimiter_1 = require("./middleware/rateLimiter");
const logger_1 = __importDefault(require("./utils/logger"));
// Routes
const auth_routes_1 = __importDefault(require("./routes/auth.routes"));
const meeting_routes_1 = __importDefault(require("./routes/meeting.routes"));
const visitor_routes_1 = __importDefault(require("./routes/visitor.routes"));
const user_routes_1 = __importDefault(require("./routes/user.routes"));
const notification_routes_1 = __importDefault(require("./routes/notification.routes"));
const dashboard_routes_1 = __importDefault(require("./routes/dashboard.routes"));
const whatsapp_routes_1 = __importDefault(require("./routes/whatsapp.routes"));
const whatsapp_gateway_routes_1 = __importDefault(require("./routes/whatsapp-gateway.routes"));
const preregistration_routes_1 = __importDefault(require("./routes/preregistration.routes"));
// Load environment variables
dotenv_1.default.config();
const app = (0, express_1.default)();
const server = http_1.default.createServer(app);
// Behind Nginx reverse proxy on EC2
app.set('trust proxy', 1);
// Socket.IO setup
exports.io = new socket_io_1.Server(server, {
    cors: {
        origin: process.env.CORS_ORIGIN?.split(',') || '*',
        methods: ['GET', 'POST']
    },
    path: process.env.SOCKET_IO_PATH || '/socket.io'
});
// Middleware
app.use((0, helmet_1.default)());
app.use((0, cors_1.default)({
    origin: process.env.CORS_ORIGIN?.split(',') || '*',
    credentials: true
}));
app.use((0, morgan_1.default)('combined', { stream: { write: (message) => logger_1.default.info(message.trim()) } }));
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// Rate limiting
app.use(rateLimiter_1.rateLimiter);
// Health check
app.get('/health', (_req, res) => {
    res.json({
        success: true,
        message: 'SAK Access Control API is running',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV
    });
});
// API Routes
const API_PREFIX = `/api/${process.env.API_VERSION || 'v1'}`;
app.use(`${API_PREFIX}/auth`, auth_routes_1.default);
app.use(`${API_PREFIX}/meetings`, meeting_routes_1.default);
app.use(`${API_PREFIX}/visitors`, visitor_routes_1.default);
app.use(`${API_PREFIX}/users`, user_routes_1.default);
app.use(`${API_PREFIX}/notifications`, notification_routes_1.default);
app.use(`${API_PREFIX}/dashboard`, dashboard_routes_1.default);
app.use(`${API_PREFIX}/whatsapp`, whatsapp_routes_1.default);
app.use(`${API_PREFIX}/gateway`, whatsapp_gateway_routes_1.default);
app.use(`${API_PREFIX}/preregister`, preregistration_routes_1.default);
// Socket.IO connection handling
exports.io.on('connection', (socket) => {
    logger_1.default.info(`Socket connected: ${socket.id}`);
    socket.on('join_room', (userId) => {
        socket.join(`user_${userId}`);
        logger_1.default.info(`User ${userId} joined their notification room`);
    });
    socket.on('disconnect', () => {
        logger_1.default.info(`Socket disconnected: ${socket.id}`);
    });
});
// Error handling
app.use(notFound_1.notFound);
app.use(errorHandler_1.errorHandler);
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    logger_1.default.info(`🚀 Server running on port ${PORT} in ${process.env.NODE_ENV} mode`);
    logger_1.default.info(`📡 Socket.IO server ready`);
    logger_1.default.info(`🔗 API available at http://localhost:${PORT}${API_PREFIX}`);
});
// Graceful shutdown
process.on('SIGTERM', () => {
    logger_1.default.info('SIGTERM signal received: closing HTTP server');
    server.close(() => {
        logger_1.default.info('HTTP server closed');
        process.exit(0);
    });
});
exports.default = app;
//# sourceMappingURL=server.js.map