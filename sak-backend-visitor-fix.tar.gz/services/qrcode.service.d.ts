declare class QRCodeService {
    private secret;
    private jwtSecret;
    constructor();
    /**
     * Generate secure JWT-based QR code for visitor
     * Industry standard: Signed JWT with one-time use token
     */
    generateQRCode(meetingId: string, visitorId: string, visitorEmail: string, expiryDate: Date): Promise<{
        token: string;
        image: string;
        qrId: string;
    }>;
    /**
     * Verify JWT-based QR code with one-time use enforcement
     */
    verifyQRCode(token: string): Promise<any>;
    /**
     * Revoke QR code (for cancellations)
     */
    revokeQRCode(qrId: string): Promise<boolean>;
    /**
     * Legacy: Encrypt data using AES-256 with random salt (DEPRECATED)
     * Kept for backward compatibility only
     * @deprecated
     */
    private _encrypt;
    /**
     * Legacy: Decrypt data (DEPRECATED)
     * @deprecated
     */
    private _decrypt;
}
declare const _default: QRCodeService;
export default _default;
//# sourceMappingURL=qrcode.service.d.ts.map