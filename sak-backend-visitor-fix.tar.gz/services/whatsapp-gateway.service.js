"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const baileys_1 = __importStar(require("@whiskeysockets/baileys"));
const logger_1 = __importDefault(require("../utils/logger"));
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const pino_1 = __importDefault(require("pino"));
const uuid_1 = require("uuid");
/**
 * Multi-tenant WhatsApp Gateway Service
 * Similar to Maytapi but self-hosted and free
 */
class WhatsAppGatewayService {
    constructor() {
        this.sessions = new Map();
        this.sessionConfigs = new Map();
        this.qrCodes = new Map();
        this.connectionStatus = new Map();
        this.messageQueue = [];
        this.authBaseFolder = path.join(process.cwd(), 'whatsapp_sessions');
        this.initialize();
    }
    /**
     * Initialize gateway service
     */
    async initialize() {
        // Ensure sessions folder exists
        if (!fs.existsSync(this.authBaseFolder)) {
            fs.mkdirSync(this.authBaseFolder, { recursive: true });
        }
        // Load existing sessions from database or config
        // For now, auto-create a default session
        await this.createSession({
            sessionId: 'default',
            name: 'SAK Access Control',
            apiKey: process.env.WHATSAPP_GATEWAY_API_KEY || 'default-key-change-this',
            isActive: true
        });
        logger_1.default.info('WhatsApp Gateway Service initialized');
    }
    /**
     * Create a new WhatsApp session (like creating a new Maytapi phone)
     */
    async createSession(config) {
        try {
            const sessionFolder = path.join(this.authBaseFolder, config.sessionId);
            // Ensure session folder exists
            if (!fs.existsSync(sessionFolder)) {
                fs.mkdirSync(sessionFolder, { recursive: true });
            }
            const { state, saveCreds } = await (0, baileys_1.useMultiFileAuthState)(sessionFolder);
            const sock = (0, baileys_1.default)({
                auth: state,
                printQRInTerminal: false,
                logger: (0, pino_1.default)({ level: 'silent' })
            });
            // Store session config
            this.sessionConfigs.set(config.sessionId, config);
            this.sessions.set(config.sessionId, sock);
            // Connection events
            sock.ev.on('connection.update', async (update) => {
                const { connection, lastDisconnect, qr } = update;
                if (qr) {
                    this.qrCodes.set(config.sessionId, qr);
                    logger_1.default.info(`📱 QR Code generated for session: ${config.sessionId}`);
                    // Call webhook if configured
                    if (config.webhook) {
                        this.callWebhook(config.webhook, {
                            event: 'qr_code',
                            sessionId: config.sessionId,
                            qrCode: qr
                        });
                    }
                }
                if (connection === 'close') {
                    const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== baileys_1.DisconnectReason.loggedOut;
                    logger_1.default.info(`❌ Session ${config.sessionId} closed, reconnecting: ${shouldReconnect}`);
                    this.connectionStatus.set(config.sessionId, false);
                    if (shouldReconnect) {
                        setTimeout(() => this.createSession(config), 5000);
                    }
                    // Webhook notification
                    if (config.webhook) {
                        this.callWebhook(config.webhook, {
                            event: 'disconnected',
                            sessionId: config.sessionId,
                            shouldReconnect
                        });
                    }
                }
                else if (connection === 'open') {
                    logger_1.default.info(`✅ Session ${config.sessionId} connected`);
                    this.connectionStatus.set(config.sessionId, true);
                    this.qrCodes.delete(config.sessionId);
                    // Store phone number
                    const phoneNumber = sock.user?.id?.split(':')[0];
                    if (phoneNumber) {
                        config.phoneNumber = phoneNumber;
                        this.sessionConfigs.set(config.sessionId, config);
                    }
                    // Webhook notification
                    if (config.webhook) {
                        this.callWebhook(config.webhook, {
                            event: 'connected',
                            sessionId: config.sessionId,
                            phoneNumber: config.phoneNumber
                        });
                    }
                    // Process queued messages
                    this.processMessageQueue(config.sessionId);
                }
            });
            // Message received handler
            sock.ev.on('messages.upsert', async ({ messages }) => {
                await this.handleIncomingMessage(config.sessionId, messages);
            });
            // Save credentials when updated
            sock.ev.on('creds.update', saveCreds);
            return {
                success: true,
                sessionId: config.sessionId,
                qrCode: this.qrCodes.get(config.sessionId),
                message: 'Session created successfully'
            };
        }
        catch (error) {
            logger_1.default.error(`Error creating session ${config.sessionId}:`, error);
            return {
                success: false,
                sessionId: config.sessionId,
                message: error.message
            };
        }
    }
    /**
     * Handle incoming messages (for webhook forwarding)
     */
    async handleIncomingMessage(sessionId, messages) {
        const config = this.sessionConfigs.get(sessionId);
        if (!config?.webhook)
            return;
        for (const message of messages) {
            if (message.key.fromMe)
                continue; // Skip messages sent by us
            const messageData = {
                event: 'message_received',
                sessionId,
                from: message.key.remoteJid,
                messageId: message.key.id,
                timestamp: message.messageTimestamp,
                type: Object.keys(message.message || {})[0],
                text: message.message?.conversation ||
                    message.message?.extendedTextMessage?.text || '',
                hasMedia: !!(message.message?.imageMessage ||
                    message.message?.documentMessage ||
                    message.message?.videoMessage)
            };
            await this.callWebhook(config.webhook, messageData);
        }
    }
    /**
     * Call webhook URL with data
     */
    async callWebhook(webhookUrl, data) {
        try {
            const axios = require('axios');
            await axios.post(webhookUrl, data, {
                headers: { 'Content-Type': 'application/json' },
                timeout: 5000
            });
        }
        catch (error) {
            logger_1.default.error('Webhook call failed:', error);
        }
    }
    /**
     * Validate API key for session
     */
    validateApiKey(sessionId, apiKey) {
        const config = this.sessionConfigs.get(sessionId);
        return config?.apiKey === apiKey && config?.isActive === true;
    }
    /**
     * Get session status
     */
    getSessionStatus(sessionId) {
        const config = this.sessionConfigs.get(sessionId);
        return {
            exists: !!config,
            connected: this.connectionStatus.get(sessionId) || false,
            phoneNumber: config?.phoneNumber,
            qrCode: this.qrCodes.get(sessionId)
        };
    }
    /**
     * Send text message
     */
    async sendMessage(sessionId, to, text) {
        try {
            const sock = this.sessions.get(sessionId);
            const isConnected = this.connectionStatus.get(sessionId);
            if (!sock || !isConnected) {
                // Queue message for later
                this.queueMessage({
                    id: (0, uuid_1.v4)(),
                    sessionId,
                    to,
                    type: 'text',
                    content: { text },
                    retries: 0,
                    timestamp: new Date()
                });
                return {
                    success: false,
                    error: 'Session not connected, message queued'
                };
            }
            const jid = this.formatPhoneNumber(to);
            const sentMsg = await sock.sendMessage(jid, { text });
            logger_1.default.info(`Message sent via session ${sessionId} to ${to}`);
            return {
                success: true,
                messageId: sentMsg?.key?.id || undefined
            };
        }
        catch (error) {
            logger_1.default.error(`Error sending message:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    /**
     * Send image with caption
     */
    async sendImage(sessionId, to, imageBuffer, caption) {
        try {
            const sock = this.sessions.get(sessionId);
            const isConnected = this.connectionStatus.get(sessionId);
            if (!sock || !isConnected) {
                this.queueMessage({
                    id: (0, uuid_1.v4)(),
                    sessionId,
                    to,
                    type: 'image',
                    content: { imageBuffer, caption },
                    retries: 0,
                    timestamp: new Date()
                });
                return {
                    success: false,
                    error: 'Session not connected, message queued'
                };
            }
            const jid = this.formatPhoneNumber(to);
            const sentMsg = await sock.sendMessage(jid, {
                image: imageBuffer,
                caption: caption || ''
            });
            return {
                success: true,
                messageId: sentMsg?.key?.id || undefined
            };
        }
        catch (error) {
            logger_1.default.error(`Error sending image:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    /**
     * Send document
     */
    async sendDocument(sessionId, to, documentBuffer, filename, caption) {
        try {
            const sock = this.sessions.get(sessionId);
            const isConnected = this.connectionStatus.get(sessionId);
            if (!sock || !isConnected) {
                this.queueMessage({
                    id: (0, uuid_1.v4)(),
                    sessionId,
                    to,
                    type: 'document',
                    content: { documentBuffer, filename, caption },
                    retries: 0,
                    timestamp: new Date()
                });
                return {
                    success: false,
                    error: 'Session not connected, message queued'
                };
            }
            const jid = this.formatPhoneNumber(to);
            const sentMsg = await sock.sendMessage(jid, {
                document: documentBuffer,
                fileName: filename,
                caption: caption || '',
                mimetype: 'application/pdf'
            });
            return {
                success: true,
                messageId: sentMsg?.key?.id || undefined
            };
        }
        catch (error) {
            logger_1.default.error(`Error sending document:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    /**
     * Queue message for retry
     */
    queueMessage(message) {
        this.messageQueue.push(message);
        logger_1.default.info(`Message queued: ${message.id}`);
    }
    /**
     * Process queued messages for a session
     */
    async processMessageQueue(sessionId) {
        const messages = this.messageQueue.filter(m => m.sessionId === sessionId);
        for (const msg of messages) {
            if (msg.retries >= 3) {
                // Remove failed messages after 3 retries
                this.messageQueue = this.messageQueue.filter(m => m.id !== msg.id);
                continue;
            }
            try {
                if (msg.type === 'text') {
                    await this.sendMessage(sessionId, msg.to, msg.content.text);
                }
                else if (msg.type === 'image') {
                    await this.sendImage(sessionId, msg.to, msg.content.imageBuffer, msg.content.caption);
                }
                else if (msg.type === 'document') {
                    await this.sendDocument(sessionId, msg.to, msg.content.documentBuffer, msg.content.filename, msg.content.caption);
                }
                // Remove from queue on success
                this.messageQueue = this.messageQueue.filter(m => m.id !== msg.id);
            }
            catch (error) {
                msg.retries++;
            }
        }
    }
    /**
     * Format phone number
     */
    formatPhoneNumber(phone) {
        let cleaned = phone.replace(/\D/g, '');
        if (!cleaned.startsWith('91') && cleaned.length === 10) {
            cleaned = '91' + cleaned;
        }
        return cleaned + '@s.whatsapp.net';
    }
    /**
     * Delete session
     */
    async deleteSession(sessionId) {
        try {
            const sock = this.sessions.get(sessionId);
            if (sock) {
                await sock.logout();
            }
            this.sessions.delete(sessionId);
            this.sessionConfigs.delete(sessionId);
            this.connectionStatus.delete(sessionId);
            this.qrCodes.delete(sessionId);
            // Delete auth folder
            const sessionFolder = path.join(this.authBaseFolder, sessionId);
            if (fs.existsSync(sessionFolder)) {
                fs.rmSync(sessionFolder, { recursive: true });
            }
            logger_1.default.info(`Session ${sessionId} deleted`);
            return true;
        }
        catch (error) {
            logger_1.default.error(`Error deleting session ${sessionId}:`, error);
            return false;
        }
    }
    /**
     * List all sessions
     */
    listSessions() {
        return Array.from(this.sessionConfigs.values()).map(config => ({
            ...config,
            apiKey: '***' + config.apiKey.slice(-4) // Mask API key
        }));
    }
}
exports.default = new WhatsAppGatewayService();
//# sourceMappingURL=whatsapp-gateway.service.js.map