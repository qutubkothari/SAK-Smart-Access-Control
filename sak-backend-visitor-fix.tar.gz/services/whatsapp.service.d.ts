declare class WhatsAppService {
    private sock;
    private authFolder;
    private isConnected;
    private qrCode;
    constructor();
    /**
     * Initialize WhatsApp connection
     */
    initialize(): Promise<void>;
    /**
     * Get current QR code for scanning
     */
    getQRCode(): string | null;
    /**
     * Check if WhatsApp is connected
     */
    isWhatsAppConnected(): boolean;
    /**
     * Format phone number for WhatsApp (add country code and @s.whatsapp.net)
     */
    private formatPhoneNumber;
    /**
     * Send WhatsApp text message
     */
    sendMessage(to: string, text: string): Promise<string | null>;
    /**
     * Send WhatsApp message with image
     */
    sendMessageWithImage(to: string, caption: string, imageBuffer: Buffer): Promise<string | null>;
    /**
     * Send document (PDF, etc.) via WhatsApp
     */
    sendDocument(to: string, documentBuffer: Buffer, filename: string, caption?: string): Promise<string | null>;
    /**
     * Send QR code via WhatsApp (with image)
     */
    sendQRCode(to: string, visitorName: string, meetingDetails: string, qrImageBuffer: Buffer): Promise<string | null>;
    /**
     * Send visitor arrival notification to host
     */
    notifyHostVisitorArrived(to: string, hostName: string, visitorName: string, location: string): Promise<string | null>;
    /**
     * Send meeting reminder
     */
    sendMeetingReminder(to: string, hostName: string, meetingTime: string, location: string): Promise<string | null>;
    /**
     * Disconnect WhatsApp
     */
    disconnect(): Promise<void>;
}
declare const _default: WhatsAppService;
export default _default;
//# sourceMappingURL=whatsapp.service.d.ts.map