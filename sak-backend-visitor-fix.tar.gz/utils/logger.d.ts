import winston from 'winston';
declare const logger: winston.Logger;
export default logger;
//# sourceMappingURL=logger.d.ts.map