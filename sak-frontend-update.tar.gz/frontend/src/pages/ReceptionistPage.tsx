import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { visitorApi } from '../services/api';
import { QrCode, CheckCircle, User, Mail, Phone, Building, Camera } from 'lucide-react';
import { formatDateTime } from '../utils/formatters';
import { WebcamCapture } from '../components/PhotoCapture';
import type { Visitor } from '../types';

export const ReceptionistPage: React.FC = () => {
  const [qrCode, setQrCode] = useState('');
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [showPhotoCapture, setShowPhotoCapture] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string>('');

  const handleScan = async () => {
    if (!qrCode.trim()) return;
    
    setError('');
    setSuccess(false);
    setLoading(true);

    try {
      // If photo was captured, send it along with check-in
      let checkInData: any = { qrCode };
      
      if (capturedPhoto) {
        // Convert base64 to blob
        const photoBlob = await fetch(capturedPhoto).then(r => r.blob());
        const photoFile = new File([photoBlob], 'visitor-photo.jpg', { type: 'image/jpeg' });
        
        const formData = new FormData();
        formData.append('qr_code', qrCode);
        formData.append('photo', photoFile);
        
        const response = await visitorApi.checkInWithPhoto(formData);
        setVisitor(response.data);
      } else {
        const response = await visitorApi.checkIn(qrCode);
        setVisitor(response.data);
      }
      
      setSuccess(true);
      setQrCode('');
      setCapturedPhoto('');
      setShowPhotoCapture(false);
    } catch (err: any) {
      setError(err.response?.data?.error?.message || 'Failed to check in visitor');
      setVisitor(null);
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoCapture = (photoDataUrl: string) => {
    setCapturedPhoto(photoDataUrl);
    setShowPhotoCapture(false);
  };

  const handleCheckOut = async (visitorId: string) => {
    try {
      await visitorApi.checkOut(visitorId);
      setVisitor(null);
      setSuccess(false);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to check out visitor');
    }
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Visitor Check-In</h1>
          <p className="text-gray-600 mt-1">Scan QR code to check in visitors</p>
        </div>

        {/* QR Scanner */}
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <QrCode className="text-primary-600" size={24} />
            <h2 className="text-xl font-bold text-gray-900">Scan QR Code</h2>
          </div>

          <div className="space-y-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={qrCode}
                onChange={(e) => setQrCode(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleScan()}
                placeholder="Scan or enter QR code"
                className="input-field flex-1"
                autoFocus
              />
              <button
                onClick={() => setShowPhotoCapture(true)}
                className="btn-secondary px-4"
                title="Capture Photo"
              >
                <Camera size={20} />
              </button>
              <button
                onClick={handleScan}
                disabled={loading || !qrCode.trim()}
                className="btn-primary px-6 disabled:opacity-50"
              >
                {loading ? 'Checking...' : 'Check In'}
              </button>
            </div>

            {capturedPhoto && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-3">
                <img src={capturedPhoto} alt="Visitor" className="w-16 h-16 rounded-lg object-cover" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-green-700">Photo captured</p>
                  <p className="text-xs text-green-600">Will be attached to check-in</p>
                </div>
                <button
                  onClick={() => setCapturedPhoto('')}
                  className="text-red-600 hover:text-red-700 text-sm"
                >
                  Remove
                </button>
              </div>
            )}

            {showPhotoCapture && (
              <div className="border-2 border-primary-200 rounded-lg p-4 bg-primary-50">
                <h3 className="font-medium text-gray-900 mb-4">Capture Visitor Photo</h3>
                <WebcamCapture
                  onCapture={handlePhotoCapture}
                  onCancel={() => setShowPhotoCapture(false)}
                />
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            {success && visitor && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                <div className="flex items-center gap-2 text-green-700 font-medium mb-4">
                  <CheckCircle size={24} />
                  <span className="text-lg">Check-in Successful!</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-start gap-3">
                    <User className="text-green-600 mt-1" size={18} />
                    <div>
                      <p className="text-gray-600">Visitor Name</p>
                      <p className="font-medium text-gray-900">{visitor.name}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail className="text-green-600 mt-1" size={18} />
                    <div>
                      <p className="text-gray-600">Email</p>
                      <p className="font-medium text-gray-900">{visitor.email}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone className="text-green-600 mt-1" size={18} />
                    <div>
                      <p className="text-gray-600">Phone</p>
                      <p className="font-medium text-gray-900">{visitor.phone}</p>
                    </div>
                  </div>

                  {visitor.company && (
                    <div className="flex items-start gap-3">
                      <Building className="text-green-600 mt-1" size={18} />
                      <div>
                        <p className="text-gray-600">Company</p>
                        <p className="font-medium text-gray-900">{visitor.company}</p>
                      </div>
                    </div>
                  )}

                  {visitor.badgeNumber && (
                    <div className="flex items-start gap-3">
                      <div className="text-green-600 mt-1 font-bold">##</div>
                      <div>
                        <p className="text-gray-600">Badge Number</p>
                        <p className="font-medium text-gray-900">{visitor.badgeNumber}</p>
                      </div>
                    </div>
                  )}

                  {visitor.checkInTime && (
                    <div className="flex items-start gap-3">
                      <CheckCircle className="text-green-600 mt-1" size={18} />
                      <div>
                        <p className="text-gray-600">Checked In</p>
                        <p className="font-medium text-gray-900">
                          {formatDateTime(visitor.checkInTime)}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {visitor.meeting && (
                  <div className="mt-4 pt-4 border-t border-green-200">
                    <p className="text-sm text-gray-600">Meeting Details</p>
                    <p className="font-medium text-gray-900 mt-1">
                      {visitor.meeting.location}
                      {visitor.meeting.roomNumber && ` - ${visitor.meeting.roomNumber}`}
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      {formatDateTime(visitor.meeting.meetingTime)}
                    </p>
                  </div>
                )}

                <button
                  onClick={() => handleCheckOut(visitor.id)}
                  className="w-full mt-4 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg"
                >
                  Check Out
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Instructions */}
        <div className="card bg-blue-50 border-blue-200">
          <h3 className="font-medium text-blue-900 mb-2">Instructions:</h3>
          <ul className="text-sm text-blue-700 space-y-1 list-disc list-inside">
            <li>Ask the visitor to present their QR code</li>
            <li>Scan the QR code using a scanner or manually enter the code</li>
            <li>Verify visitor details on the screen</li>
            <li>Issue a visitor badge if required</li>
            <li>Direct the visitor to the meeting location</li>
          </ul>
        </div>
      </div>
    </Layout>
  );
};
